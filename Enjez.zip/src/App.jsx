import Login from "./pages/auth/Login";

// import Signup from "./pages/auth/Signup";

function App() {
  return <Login />;
}

export default App;
