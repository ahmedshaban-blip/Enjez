export default function Services() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 mb-2">Services</h1>
      <p className="text-slate-500 text-sm">
        This is a placeholder page for Services.
      </p>
    </div>
  );
}
