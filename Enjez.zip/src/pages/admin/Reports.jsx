export default function Reports() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 mb-2">Reports</h1>
      <p className="text-slate-500 text-sm">
        This is a placeholder page for Reports.
      </p>
    </div>
  );
}
