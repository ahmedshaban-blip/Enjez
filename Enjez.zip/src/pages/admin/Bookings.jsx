export default function Bookings() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 mb-2">Bookings</h1>
      <p className="text-slate-500 text-sm">
        This is a placeholder page for Bookings. You can add tables and filters
        here later.
      </p>
    </div>
  );
}
